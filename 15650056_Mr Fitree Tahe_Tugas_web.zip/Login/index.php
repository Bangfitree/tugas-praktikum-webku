<!DOCTYPE html>
<html>
<link rel='stylesheet' type='text/css' href='thema/<?php echo 'default'; ?>.css' />
<head>
<title>Pratikum Pemrograman WEB</title>
<?php
require 'koneksi.php';
$tema = 'default';
	if (isset($_POST['submit'])) {
		$username = $_POST['username'];
		$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
		$privileges = $_POST['privileges'];
		$query = mysql_query("INSERT into login
		VALUES('','$username','$password','$privileges')");
		if($query){
			header('location: ./login.php');
			} 
		else{
			echo "Gagal register";
			}
	}
?>
</head>
<body>
<form method="POST">
<h2>Daftar</h2>
<table>
<tr>
<td>Username</td>
<td><input type="text" name="username" placeholder='Username'></td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" name="password" placeholder='Password'></td>
</tr>
<tr>
<td>Hak akses</td>
<td>
<select name="privileges">
<option disabled selected>--pilih hak akses--</option>
<option value="1">Admin</option>
<option value="0">User</option>
</select>
</td>
</tr>
<tr>
<td><button type="submit" name="submit" value="Register">Register</td>
</tr>
</table>

</form>

</body>

</html>