<!DOCTYPE html>
<html>
<link rel='stylesheet' type='text/css' href='thema/<?php echo 'default'; ?>.css' />
<head>
<title>Pratikum Pemrograman WEB</title>
<?php
require 'koneksi.php';
session_start();
if (isset($_POST['submit'])) {
$username = $_POST['username'];
$password = $_POST['password'];
$query = mysql_query("SELECT * FROM login WHERE username =
'$username' LIMIT 1");
$hasil = mysql_fetch_array($query);
if (password_verify($password, $hasil['password'])) {
$_SESSION['username'] = $hasil['username'];
if($hasil['privilege'] == 1){
header('location: ./home_admin.php');
} else{
header('location: ./home_user.php');
}
} else {
echo 'Invalid password.';
}
}
?>
</head>
<body>
<form method="POST">
<h2>Login</h2>
<table>
<tr>
<td>Username</td>
<td><input type="text" name="username" placeholder='Username'></td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" name="password" placeholder='Password'></td>
</tr>
<tr>
<td><button type="submit" name="submit" value="Login">Login</td>
</tr>
</table>
</form>
</body>
</html>