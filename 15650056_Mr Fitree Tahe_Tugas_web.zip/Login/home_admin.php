<!DOCTYPE html>
<html>
<link rel='stylesheet' type='text/css' href='thema/<?php echo 'default'; ?>.css' />
<head>
<title>Pratikum Pemrograman WEB</title>
</head>
<body>
<?php
require 'koneksi.php';
session_start();
if($_SESSION['username']){
echo "Home Admin, selamat datang: ".$_SESSION['username'];?>
<br>
<a href="logout.php">Logout</a>
<?php } else{
header('location: ./login.php');
}
?>
</body>
</html>