<!DOCTYPE html>
<html>
<head>
  <title>CRUD PHP</title>
  <meta charset="utf-8" />
  <link rel='stylesheet' type='text/css' href='thema/<?php echo 'default'; ?>.css' />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

  <!-- Site Properties -->
  <title>Login Example - Semantic</title>
  <link rel="stylesheet" type="text/css" href="dist/components/reset.css">
  <link rel="stylesheet" type="text/css" href="dist/components/site.css">
  <link rel="stylesheet" type="text/css" href="dist/components/table.css">
  <link rel="stylesheet" type="text/css" href="dist/components/container.css">
  <link rel="stylesheet" type="text/css" href="dist/components/grid.css">
  <link rel="stylesheet" type="text/css" href="dist/components/header.css">
  <link rel="stylesheet" type="text/css" href="dist/components/image.css">
  <link rel="stylesheet" type="text/css" href="dist/components/menu.css">

  <link rel="stylesheet" type="text/css" href="dist/components/divider.css">
  <link rel="stylesheet" type="text/css" href="dist/components/segment.css">
  <link rel="stylesheet" type="text/css" href="dist/components/form.css">
  <link rel="stylesheet" type="text/css" href="dist/components/input.css">
  <link rel="stylesheet" type="text/css" href="dist/components/button.css">
  <link rel="stylesheet" type="text/css" href="dist/components/list.css">
  <link rel="stylesheet" type="text/css" href="dist/components/message.css">
  <link rel="stylesheet" type="text/css" href="dist/components/icon.css">

  <style type="text/css">
  h1 {
	  text-align: center;
	  color : red;
	}
    body {
      background-color: lightblack;
    }
    body > .grid {
      height: 100%;
    }
    .image {
      margin-top: -100px;
    }
    .column {
      max-width: 450px;
    }
  </style>
</head>
<body>
<h1> Data Berita </h1 <br>
<table class="ui inverted right aligned table">
<tr>
		<th>No</th>
		<th>Judul Berita</th>
		<th>Headline Berita</th>
		<th>Isi Berita</th>
		<th>Author</th>
		<th>Tanggal Post</th>
		<th>Aksi</th>
</tr>
		<?php
				require 'koneksi.php';
				$no = 1;
				$query = mysql_query("SELECT * FROM berita");
				while ($hasil = mysql_fetch_array($query)) { ?>
				<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $hasil[1]?></td>
				<td><?php echo $hasil[2]?></td>
				<td><?php echo $hasil[3]?></td>
				<td><?php echo $hasil[4]?></td>
				<td><?php echo $hasil[5]?></td>
				<td> 
				<a href="update.php?berita_id=<?php echo $hasil[0]?>"><input class="blue ui button" type= "submit" name="submit" value ="Update"></a>
				<a href="delete.php?berita_id=<?php echo $hasil[0]?>"><input class="red ui button" type= "submit" name="submit" value ="Delete"></a>
				</td>
				</tr>
<?php }?>
		</table>
		<td><a href="index.php"><input class="ui inverted blue button" type= "submit" name="submit" value ="Kembali"></td>
</body>
</html>