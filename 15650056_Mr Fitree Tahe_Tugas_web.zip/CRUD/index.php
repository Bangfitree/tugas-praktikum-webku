<!DOCTYPE html>
<html>
<head>  <meta charset="utf-8" />
  <link rel='stylesheet' type='text/css' href='thema/<?php echo 'default'; ?>.css' />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

  <!-- Site Properties -->
  <title>Login Example - Semantic</title>
  <link rel="stylesheet" type="text/css" href="dist/components/reset.css">
  <link rel="stylesheet" type="text/css" href="dist/components/site.css">
  <link rel="stylesheet" type="text/css" href="dist/components/table.css">
  <link rel="stylesheet" type="text/css" href="dist/components/container.css">
  <link rel="stylesheet" type="text/css" href="dist/components/grid.css">
  <link rel="stylesheet" type="text/css" href="dist/components/header.css">
  <link rel="stylesheet" type="text/css" href="dist/components/image.css">
  <link rel="stylesheet" type="text/css" href="dist/components/menu.css">

  <link rel="stylesheet" type="text/css" href="dist/components/divider.css">
  <link rel="stylesheet" type="text/css" href="dist/components/segment.css">
  <link rel="stylesheet" type="text/css" href="dist/components/form.css">
  <link rel="stylesheet" type="text/css" href="dist/components/input.css">
  <link rel="stylesheet" type="text/css" href="dist/components/button.css">
  <link rel="stylesheet" type="text/css" href="dist/components/list.css">
  <link rel="stylesheet" type="text/css" href="dist/components/message.css">
  <link rel="stylesheet" type="text/css" href="dist/components/icon.css">

  <style type="text/css">
	body h2 {
		text-align: center;
	}
    body {
      background-color: lightblue;
    }
    body > .grid {
      height: 100%;
    }
    .image {
      margin-top: -100px;
    }
    .column {
      max-width: 450px;
    }
  </style> 
		<title>CRUD PHP</title>
		<?php
		require 'koneksi.php';
		if (isset($_POST['submit'])) {
				$berita_judul 			= $_POST['berita_judul'];
				$berita_headline 		= $_POST['berita_headline'];
				$berita_isi 			= $_POST['berita_isi'];
				$berita_author 			= $_POST['berita_author'];
				$berita_tanggal 		= date('Y-m-d H:i:s');
				$query 					= mysql_query("INSERT into berita
						VALUES('','$berita_judul','$berita_headline','$berita_isi',
						'$berita_author', '$berita_tanggal')");
			if($query){
					header('location: ./read.php');
			} else{
					echo "Gagal input";
			}
			}
				?>
</head>
<body>
<h2>Input Data Berita</h2>
<form method="POST" class="ui padded called left aligned table">
<table>
		<tr>
				<td>Judul Berita</td>
				<td><input type="text" name="berita_judul"></td>
		</tr>
		<tr>
				<td>Headline Berita</td>
				<td><input type="text" name="berita_headline"></td>
		</tr>
		<tr>
		<td>Isi Berita</td>
				<td><input type="text" name="berita_isi"></td>
		</tr>
		<tr>
				<td>Penulis Berita</td>
				<td><input type="text" name="berita_author"></td>
		</tr>
		<tr>
				<td><input class="blue ui button"type="submit" name="submit" value="SIMPAN"></td>
		</tr>
</table>
</form>
</body>
</html>